$Root = "C:\openclaw-windows-worker"
$PollerSource = ".\poller.ps1"
$LauncherSource = ".\launch-worker-hidden.ps1"
$PollerTarget = Join-Path $Root "poller.ps1"
$LauncherTarget = Join-Path $Root "launch-worker-hidden.ps1"
$StartupDir = [Environment]::GetFolderPath("Startup")
$StartupBat = Join-Path $StartupDir "openclaw-worker-startup.bat"

if (-not (Test-Path $Root)) {
    New-Item -ItemType Directory -Path $Root | Out-Null
}

Copy-Item -Path $PollerSource -Destination $PollerTarget -Force
Copy-Item -Path $LauncherSource -Destination $LauncherTarget -Force

$BatContent = @"
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$LauncherTarget"
"@

Set-Content -Path $StartupBat -Value $BatContent -Encoding ASCII

Write-Host "Startup installed."
Write-Host "launcher: $LauncherTarget"
Write-Host "startup: $StartupBat"
Write-Host "Test now:"
Write-Host "powershell -ExecutionPolicy Bypass -File $LauncherTarget"
