$Root = "C:\openclaw-windows-worker"
$Poller = Join-Path $Root "poller.ps1"

if (-not (Test-Path $Poller)) {
    throw "poller.ps1 not found: $Poller"
}

$LogDir = Join-Path $Root "logs"
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir | Out-Null
}

$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$StdOutLog = Join-Path $LogDir "worker-$Stamp.log"
$StdErrLog = Join-Path $LogDir "worker-$Stamp.err.log"

Start-Process -FilePath "powershell.exe" `
    -ArgumentList @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", $Poller
    ) `
    -WindowStyle Hidden `
    -RedirectStandardOutput $StdOutLog `
    -RedirectStandardError $StdErrLog

Write-Host "Worker started in background."
Write-Host "stdout: $StdOutLog"
Write-Host "stderr: $StdErrLog"
