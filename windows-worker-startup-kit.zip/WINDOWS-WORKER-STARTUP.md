# Windows Worker 常驻启动

## 文件

- `poller.ps1`：前台轮询主程序
- `launch-worker-hidden.ps1`：后台隐藏窗口启动器
- `install-worker-startup.ps1`：安装“登录即自启”

## 一次性安装

先把 `poller.ps1`、`launch-worker-hidden.ps1`、`install-worker-startup.ps1` 放到同一目录，然后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\install-worker-startup.ps1
```

执行后会：

- 复制脚本到 `C:\openclaw-windows-worker`
- 写入启动项：`%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\openclaw-worker-startup.bat`

## 立即后台启动

```powershell
powershell -ExecutionPolicy Bypass -File C:\openclaw-windows-worker\launch-worker-hidden.ps1
```

## 验证

```powershell
Get-Process powershell | Sort-Object StartTime -Descending | Select-Object -First 3 Id,StartTime,Path
Get-ChildItem C:\openclaw-windows-worker\logs | Sort-Object LastWriteTime -Descending | Select-Object -First 5
```

## 停止

最稳妥方式是先找最新日志，再结束对应的 PowerShell 进程。
