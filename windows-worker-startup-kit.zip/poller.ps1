$ErrorActionPreference = "Stop"

$Root = "C:\openclaw-windows-worker"
$Incoming = Join-Path $Root "incoming"
$Running = Join-Path $Root "running"
$Done = Join-Path $Root "done"
$Failed = Join-Path $Root "failed"
$LogDir = Join-Path $Root "logs"
$PollSeconds = 5

foreach ($path in @($Root, $Incoming, $Running, $Done, $Failed, $LogDir)) {
    if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
    }
}

function Get-ShadowBotPath {
    $candidates = @(
        "C:\Program Files\ShadowBot",
        "C:\Program Files (x86)\ShadowBot"
    )
    foreach ($path in $candidates) {
        if (Test-Path $path) {
            return $path
        }
    }
    return $null
}

function Invoke-HealthcheckTask($Task) {
    return @{
        hostname = $env:COMPUTERNAME
        date = (Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
        node_version = (& node --version)
        git_version = (& git --version)
        shadowbot_path = (Get-ShadowBotPath)
    }
}

function Write-JsonFile($Path, $Object) {
    $Object | ConvertTo-Json -Depth 10 | Set-Content -Path $Path -Encoding UTF8
}

function Process-TaskFile($FilePath) {
    $Task = Get-Content $FilePath -Raw | ConvertFrom-Json
    $RunningPath = Join-Path $Running ([IO.Path]::GetFileName($FilePath))
    Move-Item $FilePath $RunningPath -Force
    $StartedAt = Get-Date

    try {
        if ($Task.task_type -ne "healthcheck") {
            throw "unsupported task_type: $($Task.task_type)"
        }

        $ResultPayload = Invoke-HealthcheckTask -Task $Task
        $Result = @{
            task_id = $Task.task_id
            status = "done"
            started_at = $StartedAt.ToString("o")
            finished_at = (Get-Date).ToString("o")
            worker = @{
                host = $env:COMPUTERNAME
                user = $env:USERNAME
            }
            result = $ResultPayload
            error = $null
        }
        $DonePath = Join-Path $Done "$($Task.task_id).result.json"
        Write-JsonFile -Path $DonePath -Object $Result
        Remove-Item $RunningPath -Force
    }
    catch {
        $FailedResult = @{
            task_id = $Task.task_id
            status = "failed"
            started_at = $StartedAt.ToString("o")
            finished_at = (Get-Date).ToString("o")
            worker = @{
                host = $env:COMPUTERNAME
                user = $env:USERNAME
            }
            result = $null
            error = "$($_.Exception.Message)"
        }
        $FailedPath = Join-Path $Failed "$($Task.task_id).result.json"
        Write-JsonFile -Path $FailedPath -Object $FailedResult
        if (Test-Path $RunningPath) {
            Remove-Item $RunningPath -Force
        }
    }
}

Write-Host "Windows worker started. polling $Incoming every $PollSeconds seconds..."

while ($true) {
    Get-ChildItem $Incoming -Filter "*.json" -File -ErrorAction SilentlyContinue | ForEach-Object {
        Process-TaskFile -FilePath $_.FullName
    }
    Start-Sleep -Seconds $PollSeconds
}
